# HIS & HERS HUB

Android-ready Expo starter for a multi-seller marketplace.

## Current MVP
- Login / signup UI
- Local user session
- Home product feed
- Search
- Product photo selection
- Seller product upload
- Cart
- Account/logout
- Local storage

## Run
1. Install Node.js.
2. Install Expo CLI/tools as required by the current Expo documentation.
3. In this folder run:
   npm install
   npx expo start
4. Open with Expo Go during development.

## Important
This is the first working MVP, not yet a production marketplace. For real users and Play Store release, the next phase should add:
- Firebase/Supabase authentication
- Cloud database
- Cloud image storage
- Real orders and order status
- Seller/buyer profiles
- Payments/COD workflow
- Admin dashboard
- Push notifications
- Security rules
- Production Android AAB and Play Console configuration
