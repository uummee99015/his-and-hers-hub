import React, {useEffect, useState} from "react";
import {
  SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList,
  Image, StyleSheet, Alert, ScrollView
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as ImagePicker from "expo-image-picker";

const seedProducts = [
  {id:"1", name:"Classic Watch", price:"5000", category:"Watches", image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800", seller:"Demo Seller"},
  {id:"2", name:"Leather Bag", price:"3500", category:"Bags", image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800", seller:"Demo Seller"}
];

export default function App(){
  const [screen,setScreen]=useState("home");
  const [user,setUser]=useState(null);
  const [products,setProducts]=useState(seedProducts);
  const [cart,setCart]=useState([]);
  const [search,setSearch]=useState("");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [name,setName]=useState("");
  const [productName,setProductName]=useState("");
  const [price,setPrice]=useState("");
  const [category,setCategory]=useState("");
  const [description,setDescription]=useState("");
  const [image,setImage]=useState(null);

  useEffect(()=>{
    (async()=>{
      const u=await AsyncStorage.getItem("user");
      const p=await AsyncStorage.getItem("products");
      const c=await AsyncStorage.getItem("cart");
      if(u) setUser(JSON.parse(u));
      if(p) setProducts(JSON.parse(p));
      if(c) setCart(JSON.parse(c));
    })();
  },[]);

  const saveProducts=async(p)=>{setProducts(p); await AsyncStorage.setItem("products",JSON.stringify(p));};
  const saveCart=async(c)=>{setCart(c); await AsyncStorage.setItem("cart",JSON.stringify(c));};

  const login=async()=>{
    if(!email || !password) return Alert.alert("Missing","Email aur password enter karo.");
    const u={name: email.split("@")[0], email};
    setUser(u); await AsyncStorage.setItem("user",JSON.stringify(u)); setScreen("home");
  };

  const signup=async()=>{
    if(!name || !email || !password) return Alert.alert("Missing","Sab fields fill karo.");
    const u={name,email};
    setUser(u); await AsyncStorage.setItem("user",JSON.stringify(u)); setScreen("home");
  };

  const logout=async()=>{
    await AsyncStorage.removeItem("user"); setUser(null); setScreen("login");
  };

  const pickImage=async()=>{
    const permission=await ImagePicker.requestMediaLibraryPermissionsAsync();
    if(!permission.granted) return Alert.alert("Permission required","Gallery permission allow karo.");
    const r=await ImagePicker.launchImageLibraryAsync({mediaTypes:["images"],quality:.75});
    if(!r.canceled) setImage(r.assets[0].uri);
  };

  const addProduct=async()=>{
    if(!productName || !price || !category) return Alert.alert("Missing","Product name, price aur category required hain.");
    const p={
      id:Date.now().toString(), name:productName, price, category,
      description, image:image || "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800",
      seller:user?.name || "Seller"
    };
    await saveProducts([p,...products]);
    setProductName(""); setPrice(""); setCategory(""); setDescription(""); setImage(null);
    setScreen("home"); Alert.alert("Added","Product upload ho gaya.");
  };

  const filtered=products.filter(p=>
    (p.name+" "+p.category+" "+p.seller).toLowerCase().includes(search.toLowerCase())
  );

  if(!user && screen!=="signup") return <LoginScreen email={email} setEmail={setEmail} password={password} setPassword={setPassword} login={login} goSignup={()=>setScreen("signup")}/>;
  if(!user && screen==="signup") return <SignupScreen name={name} setName={setName} email={email} setEmail={setEmail} password={password} setPassword={setPassword} signup={signup} goLogin={()=>setScreen("login")}/>;

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <Text style={styles.logo}>HIS & HERS HUB</Text>
        <TouchableOpacity onPress={()=>setScreen("cart")}><Text style={styles.cart}>🛒 {cart.length}</Text></TouchableOpacity>
      </View>

      {screen==="home" && <>
        <TextInput style={styles.search} placeholder="Search products..." value={search} onChangeText={setSearch}/>
        <FlatList
          data={filtered}
          keyExtractor={x=>x.id}
          contentContainerStyle={styles.list}
          renderItem={({item})=>
            <TouchableOpacity style={styles.card} onPress={()=>{setScreen("detail"); setImage(item.image);}}>
              <Image source={{uri:item.image}} style={styles.productImage}/>
              <View style={{flex:1,padding:10}}>
                <Text style={styles.productName}>{item.name}</Text>
                <Text style={styles.price}>Rs. {item.price}</Text>
                <Text style={styles.muted}>{item.category} • {item.seller}</Text>
                <TouchableOpacity style={styles.smallBtn} onPress={()=>saveCart([...cart,item])}>
                  <Text style={styles.btnText}>Add to Cart</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          }
        />
      </>}

      {screen==="detail" && <ScrollView contentContainerStyle={styles.page}>
        <Image source={{uri:image}} style={styles.detailImage}/>
        <Text style={styles.title}>Product</Text>
        <Text style={styles.muted}>Select a product from Home to view its details.</Text>
        <TouchableOpacity style={styles.btn} onPress={()=>setScreen("home")}><Text style={styles.btnText}>Back to Home</Text></TouchableOpacity>
      </ScrollView>}

      {screen==="upload" && <ScrollView contentContainerStyle={styles.page}>
        <Text style={styles.title}>Upload Product</Text>
        <TouchableOpacity style={styles.upload} onPress={pickImage}>
          {image ? <Image source={{uri:image}} style={styles.preview}/> : <Text>📷 Choose Product Photo</Text>}
        </TouchableOpacity>
        <TextInput style={styles.input} placeholder="Product name" value={productName} onChangeText={setProductName}/>
        <TextInput style={styles.input} placeholder="Price (Rs.)" keyboardType="numeric" value={price} onChangeText={setPrice}/>
        <TextInput style={styles.input} placeholder="Category" value={category} onChangeText={setCategory}/>
        <TextInput style={[styles.input,{height:100}]} placeholder="Description" multiline value={description} onChangeText={setDescription}/>
        <TouchableOpacity style={styles.btn} onPress={addProduct}><Text style={styles.btnText}>Upload Product</Text></TouchableOpacity>
      </ScrollView>}

      {screen==="cart" && <ScrollView contentContainerStyle={styles.page}>
        <Text style={styles.title}>My Cart</Text>
        {cart.length===0 ? <Text style={styles.muted}>Cart empty hai.</Text> : cart.map((x,i)=>
          <View style={styles.cartRow} key={i}>
            <Image source={{uri:x.image}} style={styles.thumb}/>
            <View style={{flex:1}}><Text style={styles.productName}>{x.name}</Text><Text>Rs. {x.price}</Text></View>
            <TouchableOpacity onPress={()=>saveCart(cart.filter((_,n)=>n!==i))}><Text>❌</Text></TouchableOpacity>
          </View>
        )}
        {cart.length>0 && <TouchableOpacity style={styles.btn} onPress={()=>Alert.alert("Order","Checkout system next phase mein connect hoga.")}><Text style={styles.btnText}>Checkout</Text></TouchableOpacity>}
      </ScrollView>}

      {screen==="profile" && <View style={styles.page}>
        <Text style={styles.title}>My Account</Text>
        <Text style={styles.profile}>{user.name}</Text>
        <Text style={styles.muted}>{user.email}</Text>
        <TouchableOpacity style={styles.btn} onPress={logout}><Text style={styles.btnText}>Logout</Text></TouchableOpacity>
      </View>}

      <View style={styles.nav}>
        <TouchableOpacity onPress={()=>setScreen("home")}><Text>🏠{"\n"}Home</Text></TouchableOpacity>
        <TouchableOpacity onPress={()=>setScreen("upload")}><Text>➕{"\n"}Sell</Text></TouchableOpacity>
        <TouchableOpacity onPress={()=>setScreen("cart")}><Text>🛒{"\n"}Cart</Text></TouchableOpacity>
        <TouchableOpacity onPress={()=>setScreen("profile")}><Text>👤{"\n"}Account</Text></TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

function LoginScreen({email,setEmail,password,setPassword,login,goSignup}){
  return <SafeAreaView style={styles.auth}><Text style={styles.authLogo}>HIS & HERS HUB</Text>
    <Text style={styles.title}>Welcome Back</Text>
    <TextInput style={styles.input} placeholder="Email" autoCapitalize="none" value={email} onChangeText={setEmail}/>
    <TextInput style={styles.input} placeholder="Password" secureTextEntry value={password} onChangeText={setPassword}/>
    <TouchableOpacity style={styles.btn} onPress={login}><Text style={styles.btnText}>Login</Text></TouchableOpacity>
    <TouchableOpacity onPress={goSignup}><Text style={styles.link}>Create new account</Text></TouchableOpacity>
  </SafeAreaView>;
}
function SignupScreen({name,setName,email,setEmail,password,setPassword,signup,goLogin}){
  return <SafeAreaView style={styles.auth}><Text style={styles.authLogo}>HIS & HERS HUB</Text>
    <Text style={styles.title}>Create Account</Text>
    <TextInput style={styles.input} placeholder="Name" value={name} onChangeText={setName}/>
    <TextInput style={styles.input} placeholder="Email" autoCapitalize="none" value={email} onChangeText={setEmail}/>
    <TextInput style={styles.input} placeholder="Password" secureTextEntry value={password} onChangeText={setPassword}/>
    <TouchableOpacity style={styles.btn} onPress={signup}><Text style={styles.btnText}>Sign Up</Text></TouchableOpacity>
    <TouchableOpacity onPress={goLogin}><Text style={styles.link}>Already have an account? Login</Text></TouchableOpacity>
  </SafeAreaView>;
}

const styles=StyleSheet.create({
  safe:{flex:1,backgroundColor:"#f7f7f7"}, header:{height:62,paddingHorizontal:16,flexDirection:"row",alignItems:"center",justifyContent:"space-between",backgroundColor:"#111"},
  logo:{color:"#fff",fontSize:20,fontWeight:"800"},cart:{color:"#fff",fontSize:16},search:{margin:12,padding:13,borderRadius:12,backgroundColor:"#fff",borderWidth:1,borderColor:"#ddd"},
  list:{padding:12,paddingBottom:100},card:{backgroundColor:"#fff",borderRadius:14,marginBottom:12,overflow:"hidden",flexDirection:"row",elevation:2},productImage:{width:125,height:145},productName:{fontSize:17,fontWeight:"700"},price:{fontSize:17,fontWeight:"800",marginTop:6},muted:{color:"#777",marginTop:5},
  smallBtn:{backgroundColor:"#111",padding:8,borderRadius:8,alignSelf:"flex-start",marginTop:10},btnText:{color:"#fff",fontWeight:"700",textAlign:"center"},btn:{backgroundColor:"#111",padding:15,borderRadius:12,marginTop:12},
  nav:{position:"absolute",bottom:0,left:0,right:0,height:68,backgroundColor:"#fff",borderTopWidth:1,borderColor:"#ddd",flexDirection:"row",justifyContent:"space-around",alignItems:"center"},
  page:{padding:16,paddingBottom:100},title:{fontSize:25,fontWeight:"800",marginBottom:18},input:{backgroundColor:"#fff",borderWidth:1,borderColor:"#ddd",borderRadius:12,padding:14,marginBottom:12},upload:{height:180,borderWidth:1,borderColor:"#bbb",borderStyle:"dashed",borderRadius:14,justifyContent:"center",alignItems:"center",marginBottom:15},preview:{width:"100%",height:"100%",borderRadius:14},detailImage:{width:"100%",height:330,borderRadius:14,marginBottom:15},cartRow:{backgroundColor:"#fff",padding:10,borderRadius:12,marginBottom:10,flexDirection:"row",alignItems:"center"},thumb:{width:70,height:70,borderRadius:10,marginRight:12},profile:{fontSize:22,fontWeight:"700",marginBottom:4},auth:{flex:1,padding:24,justifyContent:"center",backgroundColor:"#f7f7f7"},authLogo:{fontSize:30,fontWeight:"900",marginBottom:35},link:{textAlign:"center",marginTop:18,fontWeight:"700"}
});
